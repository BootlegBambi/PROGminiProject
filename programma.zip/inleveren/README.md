# Programming miniProject Blok A
**Project**: Super-wonder-captain  
**Project team**:
* Youri van der Star  
* Michiel Slagboom  
* Amber van den Broek  
* Wouter Dijk  
* Nonne Hodes  


## Vereist modules  
Voordat het programma zal draaien zijn de volgende modules nodig:  
* tkinter
* random  
* hashlib  
* http.client  
* json  
* time  
* datetime  
* urllib  
  
## Start programma  
Om het programma uit te starten moet het `main GUI.py` bestand worden uitgevoerd.  
Het is van belang dat de bovenstaande vereiste modules geinstalleerd zijn om het programma
correct te laten uitvoeren. Ook is een internet verbindinge vereist voor het programma.
Het programma is ontwikkeld en gestest met `Python v3.7`.  
  
Note: Aan te raden is om het programma vanuit Pycharm uit te voeren.  
